/* Code for Assignment 4, COMP 102 2011T2
 * Name:
 * Usercode:
 * ID:
 */

import comp102.*;


/** A program that plays Rock-Paper-Scissors with the user.
 */
public class RPS{

    /** Play one round of RPS and print out the choices and the result */
    public void playRound(){
    /* Outline of algorithm
	 make the computer's choice and store in variable
	 ask for the player's choice and store in variable
	 print out the computer's choice
	 compare the choices to work out who won and report it
     */
	// YOUR CODE HERE
    }


    /** Play 6 rounds of RPS. This method contains a loop that
     *  will call the playRound method six times.
     */
    public void playRPSGame(){
	UI.initialise();
	UI.println("Hello, let's play Rock Paper Scissors");
	UI.println("Each round, you must choose rock, paper, or scissors;");
	UI.println("The computer will do the same then report who won.");
	// YOUR CODE HERE
    }


    /** COMPLETION VERSION
	Play  RPS rounds until the player's score reaches 5 or -5.
	or the user enters "exit" or "quit"
      */
    public void playRPS2(){
	// This method is needed to make the TestRPS work.
	// You do not have to use it.
	// YOUR CODE HERE
    }



}
