/* Code for COMP 102 Assignment 4 2012
 * Name:
 * Usercode:
 * ID:
 */

import comp102.*;
import java.awt.Color;


/** The class contains two methods for analysing a sequence of temperature
  *  readings from the monitor on a temperature-controlled food-storage device.
  *  Both methods read a sequence of temperatures from
  *  the user, terminated by any non-number such as "done" or "end".
  * 
  *  analyseTemps method computes and prints out the six numbers of interest:
  *    maximum, minimum, and average temperatures.
  *    initial and final temperatures
  *    number of readings over the threshold
  *    The absolute value of the largest rise or fall between readings.
  *
  *  plotTemps plots the temperatures through the day as a simple bar graph.
  *
  * The core and completion versions of the program should not use arrays or lists -
  *  they should process each number as it is read.
  */

public class TemperatureMonitor{

  /** analyseTemps asks the user for a sequence of temperatures,
    * It computes and prints out several statistics 
    *   the maximum, minimum, and average
    *   the initial and final 
    *   the number of readings over the threshold,
    *   the largest rise or fall.
    */

  public void analyseTemps() {
      UI.clearText();
      // Abstract Algorithm:
      //  Ask user for threshold value (completion only)
      //  Initialise variables
      //  Prompt for input
      //  Loop, reading numbers and updating variables
      //  Compute and print out the analysis

      // YOUR CODE HERE
  }


  /** Reads a sequence of values (integers) from the user and plots a bar graph
   *  of them, using narrow rectangles whose heights are equal to the value.
   * The sequence is terminated by any word (non-number) such as "close" or "end".
   */
  public void plotTemps() {
      UI.clearText();
      UI.clearGraphics();
      // Draw x axis
      // Prompt for numbers
      // Loop, reading numbers and drawing bars
      // YOUR CODE HERE
  }

  public void analyseTempsCompletion() {
  }

  public void plotTempsCompletion() {
  }




}
