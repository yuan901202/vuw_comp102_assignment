/* Code for COMP 102 Assignment 2 2011
 * Name:
 * Usercode:
 * ID:
 */

import comp102.*;

/** Program for calculating amount of paint required
   to paint a room*/

public class PaintCalculator{

    static final double doorHeight = 2.1;  // Height of the doors
    static final double doorWidth = 0.8;   // Width of the doors
    static final double SqMetersPerLitre = 15;   // Area covered by 1 litres of paint

    /** Calculates and prints litres of paint needed to paint a room
	with four walls (excluding the doors, floor, and ceiling)
     */
    public void calculatePaintCore(){
    // YOUR CODE HERE
    }



}

