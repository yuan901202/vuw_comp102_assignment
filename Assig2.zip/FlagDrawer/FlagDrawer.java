/* Code for Assignment 2, COMP102, 2012
 * Name:
 * Usercode:
 * ID:
 */

import comp102.*;
import java.awt.Color;


/** Draws flags of various countries.
    The correct dimensions of the official flags varies from country to country,
    But you may assume that they are 2/3 as high as they are wide.
    The exact colours of the flags will also be difficult to match;
    It is fine to use the standard colours: red, green, blue, orange.
    You can find lots of details, including the correct dimensions and colours, of flags from
    http://www.crwflags.com/fotw/flags/    
 */
public class FlagDrawer{

    public static final double top = 100;
    public static final double left = 200;

    /** The flag for Norway is a red rectangle with
     * a blue cross with a white border, slightly off-set to the left-hand side;
     */
    public void norwayFlag(){
        UI.initialise();      // not necessary, but avoids some problems when debugging
        // YOUR CODE HERE
    }


    /** The flag for Maldives is a red rectangle with
     * a smaller green rectangle in the middle and a white crescent in the center;
     */
    public void maldivesFlag(){
	// YOUR CODE HERE
    }

    /** The flag for Greenland is a rectangle whose top half is white
     * and bottom half is red. There is a circle in the middle (off-set to left) 
     * which is also half white/red but on the opposite sides.
     */
    public void greenlandFlag(){
	// YOUR CODE HERE
    }

    /** The challenge:  The Jamaican flag has a yellow diagonal cross with 
      green triangles top and bottom, and black triangles left and right.
      There is no fillTriangle method in the UI class!
    */
    public void jamaicaFlag(){
	// YOUR CODE HERE
	
    }



}
