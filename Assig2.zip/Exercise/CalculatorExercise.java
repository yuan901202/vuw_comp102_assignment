/* Code for COMP 102 Assignment 2 2012
 * Name:
 * Usercode:
 * ID:
 */

import comp102.*;

/** Program for calculating various things
    Some methods convert between two units
    Other methods perform other simple calculations*/
public class CalculatorExercise{

    /** Convert from miles to kilometers */
    public void milesToKilometers(){
    // YOUR CODE HERE
    }




}
