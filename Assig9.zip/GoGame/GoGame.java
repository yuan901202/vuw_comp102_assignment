/* Code for COMP102 Assignment
 * Name:
 * Usercode:
 * ID:
 */

import comp102.*;
import java.awt.Color;
import java.util.*;
import java.io.*;


/** GoGame: Lets users play Go on a 19x19 board.
    The real Go board has a grid of 18x18 squares, and the stones are played on the
    corners of the squares.
    The code is slightly simpler if you have a 19x19 grid of squares and play the stones
    in the middle of the squares.
    */

public class GoGame
// YOUR CODE HERE
