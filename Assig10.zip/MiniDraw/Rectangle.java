/* Code for COMP102 Assignment 10
 * Name:
 * Usercode:
 * ID:
 */

import comp102.*;
import java.io.*;
import java.util.*;
import java.awt.Color;


/** Rectangle represents a solid rectangle shape
 *    Implements the Shape interface.
 *  Needs fields to record the position, size, and colour.
 */

public class Rectangle implements Shape {
    //fields
    // YOUR CODE HERE

    /** Constructor with explicit values
     *	Arguments are the x and y of the top left corner,
     *	the width and height, and the colour.
     */
    public Rectangle(double x, double y, double wd, double ht, Color col) {
	// YOUR CODE HERE
    }

    /** [Completion] Constructor which reads values from a file (scanner)
     *	The argument is a Scanner that contains the specification of the 
     *	Rectangle. The next 7 integers specify the position of the top
     *	left corner, and the width and height, and three ints specifying the 
     *	colour.
     */
    public Rectangle(Scanner data) {
	// YOUR CODE HERE
    }


    /** Returns true if the point (u, v) is on top of the shape */
    public boolean on(double u, double v) {
	// YOUR CODE HERE
       return false; // here to allow the template file to compile - please change
    }

    /** Changes the position of the shape by dx and dy.
     *	If it was positioned at (x, y), it will now be at (x+dx, y+dy)
     */
    public void moveBy(double dx, double dy) {
	// YOUR CODE HERE
    }

    /** Draws the rectangle on the graphics pane. It draws a black border and
     *	fills it with the color of the rectangle.
     *	It uses the drawing methods with the extra last argument of "false"
     *	so that the shape will not actually appear until the 
     *	graphics pane is redisplayed later. This gives much smoother redrawing.
     */
    public void redraw() {
	// YOUR CODE HERE
    }


    /** [Completion] Changes the width and height of the shape by the
     *	specified amounts.
     *	The amounts may be negative, which means that the shape
     *	should get smaller, at least in that direction.
     *	The shape should never become smaller than 1 pixel in width or height
     *	The center of the shape should remain the same.
     */
    public void resize (double changeWd, double changeHt) {
	// YOUR CODE HERE
    }


    /** Returns a string description of the rectangle in a form suitable for
     *	writing to a file in order to reconstruct the rectangle later
     *	The first word of the string must be Rectangle 
     */
    public String toString() {
	// YOUR CODE HERE
	return null; // here to allow the template file to compile - please change
    }

}
