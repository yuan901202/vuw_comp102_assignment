/* Code for COMP102 Assignment 10
 * Name:
 * Usercode:
 * ID:
 */

import comp102.*;
import java.io.*;
import java.util.*;
import java.awt.Color;

/** Dot represents a small circle shape of a fixed size (5 pixels).
 *  Implements the Shape interface.
 *  Needs fields to record the position, and colour.
 */

// YOUR CODE HERE
