/* Code for COMP 102 Assignment 6
 * Name:
 * Usercode:
 * ID:
 */

import comp102.*;
import java.awt.Color;
import javax.swing.JColorChooser;

public class MiniPaint implements UIButtonListener, UIMouseListener{

    // fields to remember
    //  the current shape that will be drawn when the mouse is next released.
    //  whether filled or not
    //  the position the mouse was pressed, 
    //  the name of the image file
    // YOUR CODE HERE

    //Constructor
    /** Sets up the user interface - mouselistener and buttons */
    public MiniPaint(){
	// YOUR CODE HERE
    }


    /* Respond to button presses */
    public void buttonPerformed(String cmd){
	// YOUR CODE HERE
    }



    /** Respond to mouse events */
    public void mousePerformed(String action, double x, double y) {
	// YOUR CODE HERE
	}
    }

  
    /* Helper methods for drawing the shapes, if you choose to define them */
    // YOUR CODE HERE

  // Main:  constructs new MiniPaint object
  public static void main(String[] arguments){
    MiniPaint ob = new MiniPaint();
  }	


}
