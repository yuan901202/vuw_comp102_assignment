/* Code for Assignment 6
 * Name:
 * Usercode:
 * ID:
 */

import comp102.*;


/** A Surprise object remembers the word it was given when it was constructed
    and has one method that says "Boo " followed by the word.
    It is a totally useless class!!!
 */
public class Surprise{

    //field
    // YOUR CODE HERE

    //Constructor: stores the word it is passed in the field
    // YOUR CODE HERE

    // sayBoo method
    // YOUR CODE HERE

}
