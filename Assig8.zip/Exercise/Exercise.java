/* Code for COMP102 Assignment 8
 * Name:
 * Usercode:
 * ID:
 */

import comp102.*;

/** Exercise   */

public class Exercise{

    public static void main(String[] arguments){
        new BalloonExercise();
        new PersonExercise();
    }	


}
