/* Code for Assignment 1, COMP 102
 * Name:
 * Usercode:
 * ID:
 */

import comp102.*;
import java.awt.Color;

/** A very simple program that prints out a name in two different ways*/
public class NamePrinter {

  /** Print a nametag with a name inside a box made of asterisks */
  public void printNameTag() {
      String name = UI.askString("What is your name");
      UI.println("*********************************");
      UI.println("*                               *");
      UI.println("*  HELLO, my name is            *");
      UI.println("*                               *");
      UI.println("*          " + name + "               *");
      UI.println("*                               *");
      UI.println("*********************************");
      UI.println();
     
  }


  /** Draw a nametag on the graphics pane
   *  The rectangular nametag is 300 units wide and 150 units high
   *  and the left edge is 100 units over and the top is 70 units down
   */
    public void drawNameTag(){
	String name = UI.askString("What name do you want on your tag?");
	UI.clearGraphics();                 // clears the graphics pane
	UI.drawRect(100, 70, 300, 150);      // draws the outline of a rectangle
	UI.drawString("Hello, my name is", 120, 135);  // puts the string near the top
	UI.drawString(name,  200, 170);     // puts the name near the center
    }


}
