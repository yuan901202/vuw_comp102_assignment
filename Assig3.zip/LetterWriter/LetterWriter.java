/* Code for COMP102 Assignment 3, 2012
 * Name:
 * Usercode:
 * ID:
 */

import comp102.*;
import java.awt.Color;
import java.util.*;
import java.io.*;


/** LetterWriter: Writes a series of marketing letters, each one tailored to the recipient  */

public class LetterWriter{

    /** Write out a series of at least five marketing letters. Each letter should
        be addressed to a different person and should use their name several times in
	the letter. Each letter should be marketing a different product at 60% off its
	retail price. Both the retail price and the discount price should be included
	in the letter. 
    */
    public void writeLetters(){
	// YOUR CODE HERE
    }

    /** Write out a series of at least five marketing letters. Each letter should
        be addressed to a different person and should use their name several times in
	the letter. Each letter should be marketing a different product at 60% off its
	retail price. Both the retail price and the discount price should be included
	in the letter. There should be an additional discount for larger orders.
	The number of items required for a "larger" order will be different for each letter.
    */
    public void writeLettersCompletion(){
	// YOUR CODE HERE
    }
	


}

