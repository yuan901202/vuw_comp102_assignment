/* Code for COMP 102 Assignment 3 2012
 * Name:
 * Usercode:
 * ID:
 */

import comp102.*;

/** Program to create simple animated cartoon strips using the
 *  CartoonFigure class.  
 */

public class CartoonStrip{

    /** animate creates two cartoon figures and places them on the window.
     *  Then animates them according to a fixed script by calling a series
     *  of methods on the figures.
     */
    public void animate(){
	// YOUR CODE HERE
    }

    /** dance creates a cartoon figure and places it on the window.
     *  Then makes the figure dance by calling two different dance step methods
     *  several times. 
     */
    public void dance(){
	// YOUR CODE HERE
    }

    /* this method is here to make it easy to restart the UI window from bluej*/
    public void restartUI(){
        UI.initialise();
	UI.clearGraphics();
    }



}

