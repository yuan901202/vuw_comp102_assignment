/* Code for COMP 102 Assignment 5 
 * Name:
 * Usercode:
 * ID:
 */

import comp102.*;
import java.util.*;
import java.io.*;


/** Extracts and prints information from a file of exam timetable data.
    The timetable file is called "examdata.txt"
    Each line of the file specifies an exam room for a course.
    The format of the lines is the following:
      The first token is the course code
      The second token is the exam room
      The third token is the date (day of the month).
      The fourth token is the number of students in the room.
      The last two tokens give the range of names of students in that room.
        (ie,  students whose name is alphabetically between the first name
	 and the second name, inclusive)
    Where a course is too big to fit all the students in one room, there will be
    several lines for the course, one for each room.  The date and time of the
    exam will be the same on each line.

 */

public class ExamTimes {


    /** Reads the timetable file, printing out all the lines that involve
	the specified course
	(ie, all the lines whose first token matches the course)
    */
    public void printCourse(String targetCourse){
	// YOUR CODE HERE
    }

    /** Reads the timetable file, printing out (to the UI window) all the
	course codes, rooms, and name ranges for exams on the specified date
	It will be best to read the six tokens on each line individually.
    */
    public void printSession(int targetDate){
	// YOUR CODE HERE
    }


    /** Reads the timetable file and prints out all the exams (course
	and room) that the specified student could possibly be on the specified date
	(taking into account the range of names in the rooms).
    */
    public void printPossibleExams(int targetDate, String name){
	// YOUR CODE HERE
    }

    /** (Completion - harder)
	dailyLists writes a file listing, for each date, all the course codes with
	an exam on that date, along with the number of students in the course, and
	also the total number of students expected that date.
	It may assume that the dates (which are all in the same month) go from 1 to 22.
	It may also assume that the examdata.txt file is sorted by course code.*/
    public void dailyLists(){
	// YOUR CODE HERE
    }

    
 

    // main method, primarily for the markers.
    // Please don't modify this method.
    // You may call it if you wish, but you don't need to.
    public static void main(String[] args){
	TestExamTimes.main(null);
    }


}
