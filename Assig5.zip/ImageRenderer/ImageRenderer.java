/* Code for COMP102 Assignment 5, 2012
 * Name:
 * Usercode:
 * ID:
 */

import comp102.*;
import java.util.*;
import java.io.*;
import java.awt.Color;

/** Renders plain ppm images onto the graphics panel
    ppm images are the simplest possible colour image format.
*/


public class ImageRenderer{

    public static final int left = 20;  // left edge of the image
    public static final	int top = 20;   // top edge of the image
    public static final	int pixelSize = 2;  

    /** Renders a ppm image file.
	Asks for the name of the file, then renders the image at position (left, top).
	Each pixel of the image	is rendered by a square of size pixelSize
	Assumes that
	- the colour depth is 255,
	- there is just one image in the file (not "animated"), and
	- there are no comments in the file.
	The first four tokens are P3, number of columns, number of rows, 255
	The remaining tokens are the pixel values (red, green, blue for each pixel)
    */
    public void renderImage(){
	// YOUR CODE HERE
    }

    /** Renders a ppm image file, possibly animated (multiple images in the file)
	Asks for the name of the file, then renders the image at position (left, top).
	Each pixel of the image	is rendered by a square of size pixelSize
	Renders each image in the file in turn with 200 mSec delay.
	Repeats the sequence 3 times.
	Ignores comments (starting with # and occuring after the 1st, 2nd, or 3rd token) 
	The colour depth (max colour value) may be different from 255 (scales the
	colour values appropriately)
    */
    public void renderAnimatedImage(){
	// YOUR CODE HERE
    }





}
